# About this folder: Tests

## Frontend

To run the tests, point your browser to `<yourdomainhere>/tests/frontend`
